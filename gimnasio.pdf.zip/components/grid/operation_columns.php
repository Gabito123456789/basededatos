<?php

// require_once 'components/grid/columns.php';
// require_once 'components/utils/html_utils.php';

include_once dirname(__FILE__) . '/' . 'columns.php';
include_once dirname(__FILE__) . '/' . '../utils/html_utils.php';

include_once(dirname(__FILE__) . '/operations/base_row_operation.php');
include_once(dirname(__FILE__) . '/operations/link_operation.php');
include_once(dirname(__FILE__) . '/operations/ajax_operation.php');
